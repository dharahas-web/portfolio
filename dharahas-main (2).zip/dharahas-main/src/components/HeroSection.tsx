import { useState, useEffect, useMemo } from "react";
import { ArrowDown, Download } from "lucide-react";

const roles = ["Aspiring Developer", "Creative Problem Solver", "UI/UX Enthusiast", "Tech Explorer"];

const Particle = ({ delay, left, size, duration }: { delay: number; left: number; size: number; duration: number }) => (
  <div
    className="absolute rounded-full bg-primary/30"
    style={{
      left: `${left}%`,
      bottom: "-10px",
      width: `${size}px`,
      height: `${size}px`,
      animation: `particle-drift ${duration}s linear ${delay}s infinite`,
      filter: `blur(${size > 4 ? 1 : 0}px)`,
    }}
  />
);

const HeroSection = () => {
  const [roleIdx, setRoleIdx] = useState(0);
  const [displayText, setDisplayText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentRole = roles[roleIdx];
    let timeout: ReturnType<typeof setTimeout>;

    if (!isDeleting && displayText === currentRole) {
      timeout = setTimeout(() => setIsDeleting(true), 2000);
    } else if (isDeleting && displayText === "") {
      setIsDeleting(false);
      setRoleIdx((prev) => (prev + 1) % roles.length);
    } else {
      timeout = setTimeout(
        () => {
          setDisplayText(
            isDeleting
              ? currentRole.slice(0, displayText.length - 1)
              : currentRole.slice(0, displayText.length + 1)
          );
        },
        isDeleting ? 40 : 80
      );
    }
    return () => clearTimeout(timeout);
  }, [displayText, isDeleting, roleIdx]);

  const particles = useMemo(
    () =>
      Array.from({ length: 20 }, (_, i) => ({
        id: i,
        delay: Math.random() * 8,
        left: Math.random() * 100,
        size: Math.random() * 4 + 2,
        duration: Math.random() * 10 + 12,
      })),
    []
  );

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Grid background */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(hsl(var(--primary)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--primary)) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          animation: "grid-pulse 4s ease-in-out infinite",
        }}
      />

      {/* Morphing blob */}
      <div
        className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/[0.07] blur-[80px]"
        style={{ animation: "morph 15s ease-in-out infinite" }}
      />
      <div
        className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] bg-accent/[0.05] blur-[60px]"
        style={{ animation: "morph 12s ease-in-out infinite reverse" }}
      />

      {/* Floating particles */}
      {particles.map((p) => (
        <Particle key={p.id} {...p} />
      ))}

      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">

        <h1 className="font-display text-6xl md:text-8xl font-bold mb-6 text-foreground leading-tight">
          Hi, I'm{" "}
          <span className="text-gradient">Dharahas</span>
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground mb-3 font-light">
          B.Tech CSE, 2nd Year at SR University, Warangal
        </p>

        <p className="text-primary text-lg md:text-xl font-medium mb-12 h-8">
          {displayText}
          <span className="inline-block w-0.5 h-5 bg-primary ml-0.5 align-middle" style={{ animation: "blink 1s step-end infinite" }} />
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#about"
            className="group inline-flex items-center gap-2 px-8 py-3.5 rounded-full glass text-primary hover:bg-primary/10 transition-all duration-300 hover:shadow-[0_0_30px_hsl(207_100%_50%/0.3)]"
          >
            Explore More
            <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
          </a>
          <a
            href="/resume"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground font-medium transition-all duration-300 hover:shadow-[0_0_35px_hsl(195_100%_50%/0.4)] hover:scale-105"
          >
            <Download className="w-4 h-4" />
            Download CV
          </a>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

export default HeroSection;
