import { useInView } from "@/hooks/useInView";
import { Github, Linkedin, Mail, Phone } from "lucide-react";

const ContactSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="contact" className="py-28 px-6 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div
        ref={ref}
        className={`max-w-2xl mx-auto ${inView ? "section-fade-in" : "opacity-0"}`}
      >
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-12 text-center">
          Get In <span className="text-gradient">Touch</span>
        </h2>

        <div className="flex flex-col items-center gap-6">
          <a
            href="tel:+916281232948"
            className="inline-flex items-center gap-3 px-6 py-3.5 rounded-xl glass text-foreground hover:text-primary hover:border-primary/50 hover:shadow-[0_0_20px_hsl(207_100%_50%/0.15)] transition-all duration-300 text-lg"
          >
            <Phone className="w-5 h-5 text-primary" />
            +91 6281232948
          </a>
          <a
            href="mailto:dharahas555@gmail.com"
            className="inline-flex items-center gap-3 px-6 py-3.5 rounded-xl glass text-foreground hover:text-primary hover:border-primary/50 hover:shadow-[0_0_20px_hsl(207_100%_50%/0.15)] transition-all duration-300 text-lg"
          >
            <Mail className="w-5 h-5 text-primary" />
            dharahas555@gmail.com
          </a>
        </div>

        <div className="flex items-center justify-center gap-4 mt-10">
          {[
            { icon: Github, href: "https://github.com/dharahas555-design/dharahas", label: "GitHub" },
            { icon: Linkedin, href: "https://www.linkedin.com/in/dharahas-368b7a335/", label: "LinkedIn" },
          ].map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-xl glass flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/50 hover:shadow-[0_0_20px_hsl(207_100%_50%/0.2)] hover:-translate-y-1 transition-all duration-300"
            >
              <s.icon className="w-5 h-5" />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
