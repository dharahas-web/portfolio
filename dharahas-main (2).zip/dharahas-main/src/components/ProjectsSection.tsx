import { useInView } from "@/hooks/useInView";
import { ExternalLink, ArrowUpRight } from "lucide-react";
import projectEvents from "@/assets/project-events.jpg";
import projectMovies from "@/assets/project-movies.jpg";
import projectStocks from "@/assets/project-stocks.jpg";

const projects = [
  {
    title: "Events & Sports Registration",
    desc: "A web application for managing event and sports registrations with user-friendly forms, dashboards, and real-time updates.",
    tags: ["HTML", "CSS", "JavaScript"],
    image: projectEvents,
    number: "01",
  },
  {
    title: "Movie Ticket Booking",
    desc: "A ticket booking platform for movies featuring seat selection, show timings, and a streamlined checkout experience.",
    tags: ["Web Dev", "UI/UX"],
    image: projectMovies,
    number: "02",
  },
  {
    title: "Stock Market Trading App",
    desc: "A comprehensive stock trading application designed in Figma with real-time charts, portfolio tracking, and trade execution flows.",
    tags: ["Figma", "UI Design"],
    image: projectStocks,
    number: "03",
  },
];

const ProjectsSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="projects" className="py-28 px-6 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div
        ref={ref}
        className={`max-w-5xl mx-auto ${inView ? "section-fade-in" : "opacity-0"}`}
      >
        <div className="flex items-center justify-center gap-3 mb-4">
          <span className="text-primary text-sm font-mono tracking-wider uppercase">{"{ projects }"}</span>
        </div>
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-16 text-center">
          My <span className="text-gradient">Projects</span>
        </h2>

        <div className="space-y-8">
          {projects.map((p, i) => (
            <div
              key={p.title}
              className={`group glass rounded-2xl overflow-hidden transition-all duration-500 hover:shadow-[0_20px_60px_-15px_hsl(207_100%_50%/0.25)] ${inView ? "section-fade-in" : "opacity-0"} stagger-${i + 1}`}
            >
              <div className={`flex flex-col ${i % 2 === 1 ? "md:flex-row-reverse" : "md:flex-row"}`}>
                {/* Image */}
                <div className="md:w-1/2 h-56 md:h-auto relative overflow-hidden">
                  <img
                    src={p.image}
                    alt={p.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent md:bg-gradient-to-r md:from-transparent md:to-background/20" />
                  <span className="absolute top-4 left-4 text-6xl font-display font-bold text-primary/10 group-hover:text-primary/20 transition-colors">
                    {p.number}
                  </span>
                </div>

                {/* Content */}
                <div className="md:w-1/2 p-8 md:p-10 flex flex-col justify-center">
                  <h3 className="font-display text-2xl font-bold text-foreground mb-3 flex items-center gap-2">
                    {p.title}
                    <ArrowUpRight className="w-5 h-5 text-primary opacity-0 group-hover:opacity-100 group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                  </h3>
                  <p className="text-muted-foreground text-sm mb-6 leading-relaxed">{p.desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {p.tags.map((t) => (
                      <span
                        key={t}
                        className="text-xs px-3 py-1.5 rounded-full bg-primary/10 text-primary border border-primary/20 font-medium"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
