import { useInView } from "@/hooks/useInView";
import { GraduationCap, MapPin, Calendar, BookOpen } from "lucide-react";

const EducationSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="education" className="py-28 px-6 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div
        ref={ref}
        className={`max-w-3xl mx-auto ${inView ? "section-fade-in" : "opacity-0"}`}
      >
        <div className="flex items-center justify-center gap-3 mb-4">
          <BookOpen className="w-5 h-5 text-primary" />
          <span className="text-primary text-sm font-mono tracking-wider uppercase">education</span>
        </div>
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-16 text-center">
          <span className="text-gradient">Education</span>
        </h2>

        <div className="space-y-6">
          {/* B.Tech */}
          <div className="glass rounded-2xl p-8 md:p-10 relative overflow-hidden group hover:shadow-[0_20px_60px_-15px_hsl(207_100%_50%/0.2)] transition-all duration-500">
            <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-primary via-accent to-primary/0" />
            <div className="flex items-start gap-6">
              <div className="hidden md:flex w-16 h-16 rounded-2xl bg-primary/10 items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <GraduationCap className="w-8 h-8 text-primary" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">
                    <Calendar className="w-3 h-3" />
                    2023 – Present
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-accent/10 text-accent font-medium">
                    <MapPin className="w-3 h-3" />
                    Warangal
                  </span>
                </div>
                <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                  B.Tech in Computer Science Engineering
                </h3>
                <p className="text-lg text-muted-foreground mb-3">SR University</p>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Currently in 2nd year, focusing on software development, data structures, algorithms, and system design.
                  Actively building projects and exploring modern web technologies.
                </p>
              </div>
            </div>
          </div>

          {/* Intermediate */}
          <div className="glass rounded-2xl p-8 md:p-10 relative overflow-hidden group hover:shadow-[0_20px_60px_-15px_hsl(207_100%_50%/0.2)] transition-all duration-500">
            <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-primary via-accent to-primary/0" />
            <div className="flex items-start gap-6">
              <div className="hidden md:flex w-16 h-16 rounded-2xl bg-primary/10 items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <GraduationCap className="w-8 h-8 text-primary" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">
                    <Calendar className="w-3 h-3" />
                    2021 – 2023
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-accent/10 text-accent font-medium">
                    <MapPin className="w-3 h-3" />
                    Khammam
                  </span>
                </div>
                <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                  Intermediate (MPC)
                </h3>
                <p className="text-lg text-muted-foreground mb-3">Sri Chaitanya Junior College</p>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Completed intermediate education with a focus on Mathematics, Physics, and Chemistry.
                </p>
              </div>
            </div>
          </div>

          {/* Schooling */}
          <div className="glass rounded-2xl p-8 md:p-10 relative overflow-hidden group hover:shadow-[0_20px_60px_-15px_hsl(207_100%_50%/0.2)] transition-all duration-500">
            <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-primary via-accent to-primary/0" />
            <div className="flex items-start gap-6">
              <div className="hidden md:flex w-16 h-16 rounded-2xl bg-primary/10 items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <GraduationCap className="w-8 h-8 text-primary" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">
                    <Calendar className="w-3 h-3" />
                    2021
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-accent/10 text-accent font-medium">
                    <MapPin className="w-3 h-3" />
                    Khammam
                  </span>
                </div>
                <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                  Secondary School (SSC)
                </h3>
                <p className="text-lg text-muted-foreground mb-3">Surya Success High School</p>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Completed secondary schooling with a strong academic foundation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSection;
