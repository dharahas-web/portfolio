import { useInView } from "@/hooks/useInView";
import { Code2, Palette, Lightbulb, Terminal, Sparkles } from "lucide-react";

const traits = [
  { icon: Code2, title: "Developer", desc: "Building functional web applications with modern technologies.", color: "from-primary to-accent" },
  { icon: Palette, title: "Designer", desc: "Creating intuitive UI/UX designs with tools like Figma.", color: "from-accent to-[hsl(260,80%,60%)]" },
  { icon: Lightbulb, title: "Problem Solver", desc: "Approaching challenges with creative, efficient solutions.", color: "from-[hsl(260,80%,60%)] to-primary" },
];

const AboutSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="about" className="py-28 px-6 relative">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      <div
        ref={ref}
        className={`max-w-5xl mx-auto ${inView ? "section-fade-in" : "opacity-0"}`}
      >
        <div className="flex items-center justify-center gap-3 mb-4">
          <Terminal className="w-5 h-5 text-primary" />
          <p className="text-primary text-sm font-mono tracking-wider uppercase">about.me</p>
        </div>
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-6 text-center">
          About <span className="text-gradient">Me</span>
        </h2>

        <p className="text-muted-foreground text-lg leading-relaxed text-center mb-16 max-w-2xl mx-auto">
          I'm Dharahas, a 2nd year Computer Science Engineering student at SR University, Warangal.
          I'm passionate about building real-world applications, solving complex problems, and crafting
          clean, intuitive user experiences.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {traits.map((item, i) => (
            <div
              key={item.title}
              className={`group relative p-8 rounded-2xl glass overflow-hidden transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_20px_60px_-15px_hsl(207_100%_50%/0.3)] ${inView ? "section-fade-in" : "opacity-0"} stagger-${i + 1}`}
            >
              {/* Top gradient line */}
              <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${item.color} opacity-60 group-hover:opacity-100 transition-opacity`} />

              <div className="relative z-10">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                  <item.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-display text-xl font-semibold text-foreground mb-3">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
