import { useInView } from "@/hooks/useInView";
import { Code, FileCode, Globe, Figma, Network, Monitor } from "lucide-react";

const skills = [
  { name: "C", level: 75, icon: Code, color: "207" },
  { name: "Python", level: 55, icon: FileCode, color: "195" },
  { name: "Web Dev", level: 70, icon: Globe, color: "207" },
  { name: "Figma", level: 65, icon: Figma, color: "260" },
  { name: "Networks", level: 60, icon: Network, color: "195" },
  { name: "OS", level: 60, icon: Monitor, color: "207" },
];

const SkillsSection = () => {
  const { ref, inView } = useInView();

  return (
    <section id="skills" className="py-28 px-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      {/* Ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-primary/[0.03] blur-[100px]" />

      <div
        ref={ref}
        className={`max-w-4xl mx-auto relative ${inView ? "section-fade-in" : "opacity-0"}`}
      >
        <div className="flex items-center justify-center gap-3 mb-4">
          <span className="text-primary text-sm font-mono tracking-wider uppercase">{"<skills />"}</span>
        </div>
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-16 text-center">
          My <span className="text-gradient">Skills</span>
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
          {skills.map((skill, i) => (
            <div
              key={skill.name}
              className={`group relative glass rounded-2xl p-6 text-center transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_15px_40px_-10px_hsl(${skill.color}_100%_50%/0.3)] ${inView ? "section-fade-in" : "opacity-0"} stagger-${i + 1}`}
            >
              {/* Circular progress ring */}
              <div className="relative w-20 h-20 mx-auto mb-4">
                <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
                  <circle
                    cx="40" cy="40" r="34"
                    fill="none"
                    stroke="hsl(var(--muted))"
                    strokeWidth="4"
                  />
                  <circle
                    cx="40" cy="40" r="34"
                    fill="none"
                    stroke={`hsl(${skill.color} 100% 50%)`}
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 34}`}
                    strokeDashoffset={inView ? `${2 * Math.PI * 34 * (1 - skill.level / 100)}` : `${2 * Math.PI * 34}`}
                    className="transition-all duration-1000 ease-out"
                    style={{ filter: `drop-shadow(0 0 6px hsl(${skill.color} 100% 50% / 0.5))` }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <skill.icon className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
                </div>
              </div>

              <h3 className="font-display font-semibold text-foreground text-sm mb-1">{skill.name}</h3>
              <p className="text-xs text-muted-foreground">{skill.level}%</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
