import { useEffect } from "react";

const Resume = () => {
  useEffect(() => {
    // Auto-trigger print dialog for PDF download
    const timeout = setTimeout(() => window.print(), 500);
    return () => clearTimeout(timeout);
  }, []);

  return (
    <>
      <style>{`
        @media print {
          body { margin: 0; }
          .no-print { display: none !important; }
        }
      `}</style>

      <div className="min-h-screen bg-white text-gray-900 p-8 max-w-[800px] mx-auto print:p-6">
        {/* Header */}
        <header className="text-center border-b-2 border-blue-500 pb-6 mb-6">
          <h1 className="text-4xl font-bold text-gray-900 mb-1">Dharahas</h1>
          <p className="text-blue-600 font-medium text-lg mb-3">Aspiring Developer · UI/UX Enthusiast</p>
          <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-gray-600">
            <span>📞 +91 6281232948</span>
            <span>✉️ dharahas555@gmail.com</span>
            <a href="https://github.com/dharahas555-design/dharahas" className="text-blue-600 hover:underline print:text-gray-600">GitHub</a>
            <a href="https://www.linkedin.com/in/dharahas-368b7a335/" className="text-blue-600 hover:underline print:text-gray-600">LinkedIn</a>
          </div>
        </header>

        {/* Career Objective */}
        <section className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 border-b border-gray-200 pb-1 mb-3 uppercase tracking-wide">Career Objective</h2>
          <p className="text-gray-700 leading-relaxed text-sm">
            Motivated and detail-oriented Computer Science Engineering student seeking opportunities to apply my skills in web development, UI/UX design, and problem-solving to contribute to innovative projects. Eager to leverage academic knowledge and hands-on project experience to deliver impactful, user-centric solutions in a collaborative environment.
          </p>
        </section>

        {/* Education */}
        <section className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 border-b border-gray-200 pb-1 mb-3 uppercase tracking-wide">Education</h2>
          <div className="space-y-3 text-sm">
            <div>
              <div className="flex justify-between">
                <h3 className="font-semibold text-gray-900">B.Tech in Computer Science Engineering</h3>
                <span className="text-gray-500">2023 – Present</span>
              </div>
              <p className="text-gray-600">SR University, Warangal — 2nd Year</p>
            </div>
            <div>
              <div className="flex justify-between">
                <h3 className="font-semibold text-gray-900">Intermediate (MPC)</h3>
                <span className="text-gray-500">2021 – 2023</span>
              </div>
              <p className="text-gray-600">Sri Chaitanya Junior College, Khammam</p>
            </div>
            <div>
              <div className="flex justify-between">
                <h3 className="font-semibold text-gray-900">Secondary School (SSC)</h3>
                <span className="text-gray-500">Completed 2021</span>
              </div>
              <p className="text-gray-600">Surya Success High School, Khammam</p>
            </div>
          </div>
        </section>

        {/* Technical Skills */}
        <section className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 border-b border-gray-200 pb-1 mb-3 uppercase tracking-wide">Technical Skills</h2>
          <div className="flex flex-wrap gap-2 text-sm">
            {["C", "Python", "HTML/CSS/JavaScript", "Figma", "Computer Networks", "Operating Systems", "UI/UX Design"].map((skill) => (
              <span key={skill} className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full border border-blue-200 text-xs font-medium">
                {skill}
              </span>
            ))}
          </div>
        </section>

        {/* Soft Skills */}
        <section className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 border-b border-gray-200 pb-1 mb-3 uppercase tracking-wide">Soft Skills</h2>
          <div className="flex flex-wrap gap-2 text-sm">
            {["Communication", "Teamwork", "Leadership", "Problem-Solving", "Time Management", "Adaptability"].map((skill) => (
              <span key={skill} className="px-3 py-1 bg-gray-50 text-gray-700 rounded-full border border-gray-200 text-xs font-medium">
                {skill}
              </span>
            ))}
          </div>
        </section>

        {/* Projects / Work Experience */}
        <section className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 border-b border-gray-200 pb-1 mb-3 uppercase tracking-wide">Projects (Campus)</h2>
          <div className="space-y-4 text-sm">
            <div>
              <div className="flex justify-between">
                <h3 className="font-semibold text-gray-900">Events & Sports Registration</h3>
                <span className="text-gray-500 text-xs">Campus Project</span>
              </div>
              <p className="text-gray-600 mt-1">Developed a web application for managing event and sports registrations with user-friendly forms, dashboards, and real-time updates.</p>
              <ul className="list-disc list-inside text-gray-500 text-xs mt-1 space-y-0.5">
                <li>Built responsive registration forms with validation</li>
                <li>Implemented dashboard for event organizers</li>
              </ul>
              <p className="text-gray-500 text-xs mt-1">Technologies: HTML, CSS, JavaScript</p>
            </div>
            <div>
              <div className="flex justify-between">
                <h3 className="font-semibold text-gray-900">Movie Ticket Booking</h3>
                <span className="text-gray-500 text-xs">Campus Project</span>
              </div>
              <p className="text-gray-600 mt-1">Built a ticket booking platform featuring seat selection, show timings, and a streamlined checkout experience.</p>
              <ul className="list-disc list-inside text-gray-500 text-xs mt-1 space-y-0.5">
                <li>Designed intuitive seat selection interface</li>
                <li>Created smooth booking and checkout flow</li>
              </ul>
              <p className="text-gray-500 text-xs mt-1">Technologies: Web Dev, UI/UX</p>
            </div>
            <div>
              <div className="flex justify-between">
                <h3 className="font-semibold text-gray-900">Stock Market Trading App</h3>
                <span className="text-gray-500 text-xs">Campus Project</span>
              </div>
              <p className="text-gray-600 mt-1">Designed a comprehensive stock trading application with real-time charts, portfolio tracking, and trade execution flows.</p>
              <ul className="list-disc list-inside text-gray-500 text-xs mt-1 space-y-0.5">
                <li>Created high-fidelity prototypes in Figma</li>
                <li>Designed end-to-end user journey for trading</li>
              </ul>
              <p className="text-gray-500 text-xs mt-1">Technologies: Figma, UI Design</p>
            </div>
          </div>
        </section>

        {/* Achievements / Certifications */}
        <section className="mb-6">
          <h2 className="text-xl font-bold text-blue-600 border-b border-gray-200 pb-1 mb-3 uppercase tracking-wide">Achievements & Certifications</h2>
          <ul className="list-disc list-inside text-sm text-gray-700 space-y-1.5">
            <li>Completed multiple campus-level projects demonstrating full-cycle development</li>
            <li>Proficient in UI/UX design with hands-on Figma experience</li>
            <li>Strong foundation in computer science fundamentals including Networks and OS</li>
          </ul>
        </section>

        {/* Back button - won't show in print */}
        <div className="no-print text-center mt-8">
          <a href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            ← Back to Portfolio
          </a>
        </div>
      </div>
    </>
  );
};

export default Resume;
