import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import SkillsSection from "@/components/SkillsSection";
import ProjectsSection from "@/components/ProjectsSection";
import EducationSection from "@/components/EducationSection";
import ContactSection from "@/components/ContactSection";
import BackToTop from "@/components/BackToTop";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <ProjectsSection />
      <EducationSection />
      <ContactSection />
      <footer className="py-10 text-center border-t border-border/50">
        <p className="text-muted-foreground text-sm font-mono">
          © 2025 Dharahas · Built with <span className="text-primary">passion</span>
        </p>
      </footer>
      <BackToTop />
    </div>
  );
};

export default Index;
